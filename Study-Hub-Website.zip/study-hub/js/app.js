// Study Hub — static GitHub Pages application.
const REDEEM_CODE = "1057999az";
const STORAGE_KEY = "studyHubPremiumUnlocked";

const subjects = {
  arabic: { title: "Arabic", subtitle: "Language, literature & expression", prefix: "arabic", files: i => `arabic-${String(i).padStart(2,"0")}.jpg` },
  english: { title: "English", subtitle: "Build confidence with every word", prefix: "english", files: i => `english-${String(i).padStart(2,"0")}.jpg` },
  mathematics: { title: "Mathematics", subtitle: "Logic, numbers & problem solving", prefix: "mathematics", files: i => `mathematics-${String(i).padStart(2,"0")}.jpg` },
  computer: { title: "Computer Science", subtitle: "Discover the world of technology", prefix: "computer", files: i => `computer-${String(i).padStart(2,"0")}.jpg` }
};

const homeView = document.getElementById("homeView");
const subjectView = document.getElementById("subjectView");
const grid = document.getElementById("lessonGrid");
const modal = document.getElementById("redeemModal");
let currentSubject = null;

function isPremiumUnlocked() {
  return localStorage.getItem(STORAGE_KEY) === "true";
}

function showHome() {
  subjectView.classList.remove("active");
  homeView.classList.add("active");
  currentSubject = null;
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function openSubject(key) {
  const subject = subjects[key];
  if (!subject) return;
  currentSubject = key;
  homeView.classList.remove("active");
  subjectView.classList.add("active");
  document.getElementById("subjectTitle").textContent = subject.title;
  document.getElementById("subjectCrumb").textContent = subject.title.toUpperCase();
  document.getElementById("subjectSubtitle").textContent = subject.subtitle;
  renderLessons(key);
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function renderLessons(key) {
  const subject = subjects[key];
  const unlocked = isPremiumUnlocked();
  document.getElementById("accessLabel").innerHTML = unlocked
    ? 'ALL 07 UNLOCKED <b>·</b> PREMIUM ACTIVE'
    : '03 FREE <b>·</b> 04 PREMIUM';
  grid.innerHTML = "";

  for (let i = 1; i <= 7; i++) {
    const card = document.createElement("article");
    const locked = i >= 4 && !unlocked;
    card.className = `lesson-card${locked ? " locked-card" : ""}`;
    const imageArea = document.createElement("div");
    imageArea.className = "lesson-image";

    const number = document.createElement("span");
    number.className = "lesson-number";
    number.textContent = `LESSON ${String(i).padStart(2,"0")}`;
    imageArea.appendChild(number);

    if (locked) {
      const lock = document.createElement("div");
      lock.className = "lock-content";
      lock.innerHTML = '<span class="lock-icon">♙</span><span>PREMIUM CONTENT</span>';
      imageArea.appendChild(lock);
    } else {
      const img = document.createElement("img");
      img.src = `images/${subject.files(i)}`;
      img.alt = `${subject.title} lesson ${i}`;
      img.loading = "lazy";
      const fallback = document.createElement("div");
      fallback.className = "image-fallback";
      fallback.textContent = `Add ${subject.files(i)} to the images folder`;
      fallback.hidden = true;
      img.addEventListener("error", () => {
        img.hidden = true;
        fallback.hidden = false;
      });
      imageArea.append(img, fallback);
    }

    const info = document.createElement("div");
    info.className = "lesson-info";
    const title = document.createElement("strong");
    title.textContent = `Lesson ${String(i).padStart(2,"0")}`;
    const tag = document.createElement("span");
    tag.className = locked ? "premium-tag" : "free-tag";
    tag.textContent = locked ? "✦ PREMIUM" : "FREE";
    info.append(title, tag);
    card.append(imageArea, info);
    if (locked) {
      card.tabIndex = 0;
      card.setAttribute("role", "button");
      card.setAttribute("aria-label", "Premium lesson locked. Unlock Premium to view.");
      card.addEventListener("click", openRedeem);
      card.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") openRedeem(); });
    }
    grid.appendChild(card);
  }
}

function openRedeem() {
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  document.getElementById("redeemInput").focus();
}
function closeRedeem() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
  document.getElementById("redeemMessage").textContent = "";
}

document.querySelectorAll("[data-subject]").forEach(button => {
  button.addEventListener("click", () => openSubject(button.dataset.subject));
});
document.getElementById("backHome").addEventListener("click", showHome);
document.getElementById("brandHome").addEventListener("click", e => { e.preventDefault(); showHome(); });
document.getElementById("headerUnlock").addEventListener("click", openRedeem);
document.getElementById("closeModal").addEventListener("click", closeRedeem);
modal.addEventListener("click", e => { if (e.target === modal) closeRedeem(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeRedeem(); });

document.getElementById("redeemForm").addEventListener("submit", e => {
  e.preventDefault();
  const entered = document.getElementById("redeemInput").value.trim();
  const message = document.getElementById("redeemMessage");
  if (entered === REDEEM_CODE) {
    localStorage.setItem(STORAGE_KEY, "true");
    message.textContent = "Premium unlocked! All subjects are now available.";
    message.className = "form-message success";
    if (currentSubject) renderLessons(currentSubject);
    document.getElementById("accessLabel").textContent = "ALL 07 UNLOCKED · PREMIUM ACTIVE";
    setTimeout(closeRedeem, 1100);
  } else {
    message.textContent = "Invalid Code";
    message.className = "form-message";
  }
});

const creatorWidget = document.getElementById("creatorWidget");
document.getElementById("creatorToggle").addEventListener("click", () => creatorWidget.classList.toggle("open"));
document.getElementById("chatForm").addEventListener("submit", e => {
  e.preventDefault();
  const input = document.getElementById("chatInput");
  const value = input.value.trim();
  if (!value) return;
  addChatMessage(value, "user");
  input.value = "";
  window.setTimeout(() => {
    const reply = value === "من صانع الموقع"
      ? "الهادي بن منصور 1s3 lycee melloulech"
      : "شكراً على رسالتك! جرّب كتابة: من صانع الموقع";
    addChatMessage(reply, "bot");
  }, 550);
});
function addChatMessage(message, type) {
  const bubble = document.createElement("div");
  bubble.className = `chat-bubble ${type}`;
  bubble.textContent = message;
  const messages = document.getElementById("chatMessages");
  messages.appendChild(bubble);
  messages.scrollTop = messages.scrollHeight;
}

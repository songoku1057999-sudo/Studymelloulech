Place the 28 JPG lesson images in this folder. See ../README.md for the exact filenames.
